module.exports = {
  name: 'ping',
  execute: async (msg) => msg.reply('Pong!')
};