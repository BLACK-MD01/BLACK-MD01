module.exports = async (msg) => {
  if (msg.body.includes('https://')) msg.reply('Anti-Link triggered!');
};