// Entry point for BLACK-MD WhatsApp bot
console.log('Bot is starting...');