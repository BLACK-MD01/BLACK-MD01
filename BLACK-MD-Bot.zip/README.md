# BLACK-MD
A WhatsApp bot inspired by YESSER-MD and BMW-XMD.