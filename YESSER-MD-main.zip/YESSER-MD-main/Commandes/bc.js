const _0x2f8f07 = {
  'nomCom': 'broadcast',
  'nomCom': 'andcast',
  'aliases': ['bc', "cast"],
  'reaction': '🕳️',
  'categorie': "General"
};
zokou(_0x2f8f07, async (_0x3538d1, _0x3d7197, _0x5e996d) => {
  function _0x2b9bae(_0x2d13d3, _0x5dc34e, _0x452ddc, _0x3af174, _0x3d3c20) {
    return _0x1c95(_0x3af174 - 0x9d + 0x25c, _0x2d13d3);
  }
  const _0x4ed112 = {
    'ViGqW': function (_0x245456, _0x31ff33) {
      return _0x245456(_0x31ff33);
    },
    'hpXNn': "🙌😂 sorry bro.! your too weak to do this just cool",
    'VSqoQ': function (_0x3942d1, _0x3e05fe) {
      return _0x3942d1(_0x3e05fe);
    },
    'CHQBj': "Enter the text to announce or mention the message to announce",
    'gBeYC': function (_0x126075, _0x5cbbdb) {
      return _0x126075(_0x5cbbdb);
    },
    'TTJiE': "order reserved for the group only",
    'hnxFX': function (_0x2ef411, _0x2915df) {
      return _0x2ef411 === _0x2915df;
    },
    'ZmllO': 'Ywdvt',
    'ADZOl': "aHeVE",
    'PsJCn': function (_0x3afbcc, _0x5905b5) {
      return _0x3afbcc(_0x5905b5);
    },
    'AGnMz': "After the command *broadcast*, type your message to be sent to all  groups you are in,,,.",
    'LcImB': function (_0x13a4e3, _0x4b0410) {
      return _0x13a4e3 !== _0x4b0410;
    },
    'AVDnh': 'OrZip',
    'UipCx': "OJdVF",
    'xcqMU': "🤔 go to bed..!",
    'WUyKK': "*YESSER-MD is sending this message to all groups you are in*...",
    'OclUo': function (_0x457223, _0x2c0f6a) {
      return _0x457223 !== _0x2c0f6a;
    },
    'wEiyF': 'xKHbd',
    'ozGrU': "fbsEw",
    'PAKSB': function (_0x16b6fc, _0x9e3da6) {
      return _0x16b6fc + _0x9e3da6;
    },
    'FycWN': function (_0xed1e58, _0x52b0b2) {
      return _0xed1e58 + _0x52b0b2;
    },
    'NQvSP': "😂 𝗬𝗘𝗦𝗦𝗘𝗥 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧😂️\n\n❗*message* : ",
    'tCmLj': "\n\n️🌟 *Author*: ",
    'jQWcD': "https://i.ibb.co/L1M7JTP/Manul-Ofc-X.jpg",
    'xPQHk': function (_0x27e4ab, _0x209728) {
      return _0x27e4ab + _0x209728;
    }
  };
  function _0x469f40(_0x59ab7f, _0xdc2acf, _0x34038d, _0x3eff24, _0x4f29ea) {
    return _0x1c95(_0x3eff24 + 0x31b - 0x39e, _0x59ab7f);
  }
  const {
    ms: _0x8fed99,
    repondre: _0x2005ec,
    arg: _0x4ec8c3,
    nomAuteurMessage: _0x358629,
    superUser: _0x4c6078
  } = _0x5e996d;
  let _0x2e8468 = _0x4ec8c3.join(" ");
  if (!_0x4ec8c3[0x0]) {
    _0x2005ec("After the command *broadcast*, type your message to be sent to all groups you are in✅,,,.");
    return;
  }
  if (!_0x4c6078) {
    _0x2005ec("hey you!! fuck off i can't broadcast your message");
    return;
  }
  let _0x4f66d1 = await _0x3d7197.groupFetchAllParticipating();
  function _0x13c988(_0x57ee51, _0x5241b0, _0x5d93a9, _0x25c77b, _0x4dec80) {
    return _0x1c95(_0x4dec80 - 0x528 + 0x25c, _0x5241b0);
  }
  function _0x2cc774(_0x3e1da0, _0x5dd366, _0x3124af, _0x430887, _0x4f6f71) {
    return _0x1c95(_0x5dd366 + 0x2ec - 0x1, _0x4f6f71);
  }
  let _0x369b09 = Object.entries(_0x4f66d1).slice(0x0).map(_0x415dbb => _0x415dbb[0x1]);
  function _0x8dc2df(_0x5c1f76, _0x1f9e8d, _0x4628fd, _0x1ff2c6, _0x4df747) {
    return _0x1c95(_0x4628fd - 0x58 + 0x25c, _0x5c1f76);
  }
  let _0xd41245 = _0x369b09.map(_0x1d6aac => _0x1d6aac.id);
  await _0x2005ec("*yesser md is sending this message to all groups you are in*...");
  for (let _0xeef539 of _0xd41245) {
    let _0x3fbe82 = "😂𝗬𝗘𝗦𝗦𝗘𝗥 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧😂\n\n❗*message* : " + _0x2e8468 + "\n\n️‼️ *Author*: " + _0x358629;
    const _0x4da470 = {
      'url': "https://i.ibb.co/L1M7JTP/Manul-Ofc-X.jpg"
    };
    await _0x3d7197.sendMessage(_0xeef539, {
      'image': _0x4da470,
      'caption': '' + _0x3fbe82
    });
  }
});
